;

<?php $__env->startSection('contenido'); ?>
<h2>EDITAR MECANICOS</h2>

<form action="/mecanicos/<?php echo e($mecanico->id); ?>" method="POST">
    <?php echo csrf_field(); ?>    
    <?php echo method_field('PUT'); ?>
  
    <div class="mb-3">
    <label for="" class="form-label">Cedula</label>
    <input id="cedula" name="cedula" type="number" class="form-control" value="<?php echo e($mecanico->cedula); ?>">    
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Nombre</label>
    <input id="nombre" name="nombre" type="text" class="form-control" value="<?php echo e($mecanico->nombre); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Apellido</label>
    <input id="apellido" name="apellido" type="text" class="form-control" value="<?php echo e($mecanico->apellido); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Direccion</label>
    <input id="direccion" name="direccion" type="text" class="form-control" value="<?php echo e($mecanico->direccion); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Telefono</label>
    <input id="telefono" name="telefono" type="number" class="form-control" value="<?php echo e($mecanico->telefono); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Email</label>
    <input id="email" name="email" type="text" class="form-control" value="<?php echo e($mecanico->email); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Ciudad</label>
    <input id="ciudad" name="ciudad" type="text" class="form-control" value="<?php echo e($mecanico->ciudad); ?>">
  </div>
  <div class="mb-3">
    <label for="" class="form-label">Especialidad</label>
    <input id="especialidad" name="especialidad" type="text" class="form-control" value="<?php echo e($mecanico->especialidad); ?>">
  </div>




  <a href="/mecanicos" class="btn btn-secondary">Cancelar</a>
  <button type="submit" class="btn btn-primary">Guardar</button>
</form>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantillabase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectojuanfelipebarrioshidalgo\resources\views/mecanico/edit.blade.php ENDPATH**/ ?>