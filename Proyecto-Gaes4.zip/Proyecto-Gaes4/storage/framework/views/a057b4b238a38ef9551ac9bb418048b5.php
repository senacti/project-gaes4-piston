$<!doctype html>
<html lang="en">

<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

<style>
 .cabecera{
    background-color: #FFCC33 ;
    color:#white;
 }

</style>

</head>

<body>
    <img src="imagenes/Please (1).png"  alt="" widt="50px" height="50px">
 <h1 class="text-center">Mecanicos</h1><br>
<!-- Tablas jaja -->

<table class="table" style="text-align:center;font-size:10px">
      <thead class="cabecera">
        <tr>
                      <th scope="col">ID</th>
                      <th scope="col">CEDULA</th>
                      <th scope="col">NOMBRE</th>
                      <th scope="col">APELLIDO</th>
                      <th scope="col">DIRECCION</th>
                      <th scope="col">TELEFONO</th>
                      <th scope="col">EMAIL</th>
                      <th scope="col">CIUDAD</th>
                      <th scope="col">ESPECIALIDAD</th>

        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $mecanicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mecanico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($mecanico->id); ?></td>
            <td><?php echo e($mecanico->cedula); ?></td>
            <td><?php echo e($mecanico->nombre); ?></td>
            <td><?php echo e($mecanico->apellido); ?></td>
            <td><?php echo e($mecanico->direccion); ?></td>
            <td><?php echo e($mecanico->telefono); ?></td>
            <td><?php echo e($mecanico->email); ?></td>
            <td><?php echo e($mecanico->ciudad); ?></td>
            <td><?php echo e($mecanico->especialidad); ?></td>
            
        </tr>
        



        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
      
    </table>











  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\proyectojuanfelipebarrioshidalgo\resources\views/mecanico/pdf.blade.php ENDPATH**/ ?>